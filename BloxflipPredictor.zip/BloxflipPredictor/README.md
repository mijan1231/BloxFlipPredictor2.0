Open test.py to get started.
it will ask you for ur bot token from discord.
input the token. 
go to your server and use the command /crash, /mines etc.
what ever minigame gamble u want.